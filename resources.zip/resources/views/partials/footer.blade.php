<footer class="footer">
    <div><a href="void(0)">Venakateswara Steels & Springs</a> © {{date('Y')}}</div>
    <div class="ms-auto">Powered by&nbsp;<a href="void(0)">Enterprise Excellence Solutions</a></div>
  </footer>
</div>
<!-- CoreUI and necessary plugins-->
<script src="{{asset('vendors/@coreui/coreui/js/coreui.bundle.min.js')}}"></script>
<script src="{{asset('vendors/simplebar/js/simplebar.min.js')}}"></script>
<script>
</script>
