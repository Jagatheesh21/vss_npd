@if ($supplier)
<option value="{{$supplier->id}}" selected>{{$supplier->name}}</option>    
@endif
