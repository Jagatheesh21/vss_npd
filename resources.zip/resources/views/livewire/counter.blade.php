<div style="text-align: center">
    <button wire:click="increment" class="btn btn-primary">+</button>
    <h1>{{ $count }}</h1>
    <button wire:click="decrement" class="btn btn-danger">-</button>
</div>
